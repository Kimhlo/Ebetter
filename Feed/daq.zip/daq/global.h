#ifndef GLOBAL_H
#define GLOBAL_H

#endif // GLOBAL_H


extern char recData[64];
