#include <global.h>

char recData[64];
